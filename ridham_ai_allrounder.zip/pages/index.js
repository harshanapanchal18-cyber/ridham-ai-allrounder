import React, {useState, useRef, useEffect} from 'react';

export default function Home() {
  const [messages, setMessages] = useState([{id:1, who:'assistant', text:'Welcome to RIDHAM AI ALLROUNDER (Free Edition) — Ask me anything!'}]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const fileRef = useRef(null);
  const [attachments, setAttachments] = useState([]);

  useEffect(()=>{ window.scrollTo(0, document.body.scrollHeight); }, [messages]);

  function handleFiles(e){
    const files = Array.from(e.target.files || []);
    const mapped = files.map((f,i)=>({id:Date.now()+i, name:f.name, size:f.size, type:f.type}));
    setAttachments(a=>[...a, ...mapped]);
  }

  async function sendMessage(){
    if(!input.trim()) return;
    const userMsg = {id:Date.now(), who:'you', text:input};
    setMessages(m=>[...m, userMsg]);
    setInput('');
    setLoading(true);
    try{
      const res = await fetch('/api/chat', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ message: userMsg.text })
      });
      const data = await res.json();
      const reply = data.reply || data.error || 'No reply.';
      setMessages(m=>[...m, {id:Date.now()+1, who:'assistant', text:reply}]);
    }catch(err){
      setMessages(m=>[...m, {id:Date.now()+1, who:'assistant', text:'Error contacting AI backend.'}]);
    }
    setLoading(false);
  }

  return (
    <div style={{minHeight:'100vh', fontFamily:'Inter, system-ui, sans-serif', background:'linear-gradient(135deg,#7c3aed,#ec4899, #f59e0b)', color:'#fff', padding:20}}>
      <div style={{maxWidth:1100, margin:'0 auto', background:'rgba(255,255,255,0.06)', borderRadius:16, padding:20, boxShadow:'0 8px 30px rgba(0,0,0,0.2)'}}>
        <header style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12}}>
          <div>
            <h1 style={{margin:0, fontSize:26, fontWeight:800}}>RIDHAM AI ALLROUNDER</h1>
            <div style={{opacity:0.9, fontSize:13}}>Free edition — powered by Gemini (add GEMINI_API_KEY in Vercel env)</div>
          </div>
          <div style={{textAlign:'right'}}>
            <div style={{fontWeight:700}}>Founder: RIDHAM</div>
            <div style={{fontFamily:"'Baloo 2', cursive", marginTop:6}}>MADE IN INDIA ~BY RIDHAM</div>
          </div>
        </header>

        <main style={{display:'grid', gridTemplateColumns:'2fr 1fr', gap:16}}>
          <section style={{minHeight:420}}>
            <div style={{height:360, overflow:'auto', padding:12, background:'rgba(0,0,0,0.15)', borderRadius:12}}>
              {messages.map(m=>(
                <div key={m.id} style={{marginBottom:10, textAlign: m.who==='you' ? 'right':'left'}}>
                  <div style={{display:'inline-block', padding:10, borderRadius:10, background: m.who==='you' ? 'linear-gradient(90deg,#06b6d4,#3b82f6)' : 'rgba(255,255,255,0.06)', color: m.who==='you' ? '#fff':'#fff', maxWidth:'86%'}}>
                    <div style={{whiteSpace:'pre-wrap'}}>{m.text}</div>
                  </div>
                </div>
              ))}
            </div>

            <div style={{marginTop:12, display:'flex', gap:8}}>
              <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter' && sendMessage()} placeholder="Type a question..." style={{flex:1, padding:10, borderRadius:8, border:'none', outline:'none'}} />
              <input ref={fileRef} type="file" multiple style={{display:'none'}} onChange={handleFiles} />
              <button onClick={()=>fileRef.current.click()} style={{padding:'10px 12px', borderRadius:8, background:'rgba(255,255,255,0.12)', border:'none'}}>Attach</button>
              <button onClick={sendMessage} style={{padding:'10px 12px', borderRadius:8, background:'#10b981', border:'none', color:'#fff'}}>{loading?'Sending...':'Send'}</button>
            </div>

            {attachments.length>0 && <div style={{marginTop:10}}>
              {attachments.map(a=>(<div key={a.id} style={{display:'inline-block', padding:6, background:'rgba(0,0,0,0.2)', borderRadius:8, marginRight:6}}>{a.name}</div>))}
            </div>}

          </section>

          <aside style={{padding:12, background:'rgba(0,0,0,0.12)', borderRadius:12}}>
            <h3 style={{marginTop:0}}>Features</h3>
            <ul>
              <li>Chat (Gemini)</li>
              <li>Image upload (client preview)</li>
              <li>File support (PDF, video) — extendable</li>
              <li>Generative Fill UI (requires image-edit backend)</li>
            </ul>

            <div style={{marginTop:10}}>
              <small style={{opacity:0.9}}>Deploy on Vercel. Add <code>GEMINI_API_KEY</code> env var in Vercel settings.</small>
            </div>
          </aside>
        </main>

        <footer style={{marginTop:16, textAlign:'center', opacity:0.95}}>
          <small>© {new Date().getFullYear()} RIDHAM AI ALLROUNDER — Built for creators</small>
        </footer>
      </div>
    </div>
  )
}
