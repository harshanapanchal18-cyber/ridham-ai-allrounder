import fetch from 'node-fetch';

export default async function handler(req, res){
  if(req.method !== 'POST') return res.status(405).json({error:'Method not allowed'});
  const { message } = req.body || {};
  if(!message) return res.status(400).json({ error: 'No message provided' });

  // Use Google Generative Language API (Gemini). Make sure to set GEMINI_API_KEY in Vercel env vars.
  const key = process.env.GEMINI_API_KEY;
  if(!key) return res.status(500).json({ error: 'GEMINI_API_KEY not set in environment variables' });

  try{
    const url = 'https://generativelanguage.googleapis.com/v1beta2/models/gemini-1.5-pro:generateText?key=' + encodeURIComponent(key);
    const body = {
      prompt: {
        text: message
      },
      temperature: 0.2,
      maxOutputTokens: 600
    };

    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await r.json();
    // parse reply - Gemini returns candidates -> content
    const reply = (data?.candidates && data.candidates[0] && data.candidates[0].content) ? data.candidates[0].content : (data?.output?.[0]?.content || null);
    if(!reply && data?.error) return res.status(500).json({ error: 'Gemini error: ' + JSON.stringify(data.error) });
    // content may be array or string
    let text = '';
    if(Array.isArray(reply)){
      text = reply.map(p=>p.text || p).join('\n');
    } else if(typeof reply === 'string') text = reply;
    else if(reply?.text) text = reply.text;
    else text = JSON.stringify(reply).slice(0,2000);

    return res.status(200).json({ reply: text });
  }catch(err){
    console.error('Failed to get AI response:', err);
    return res.status(500).json({ error: 'Failed to process chat: ' + err.message });
  }
}
