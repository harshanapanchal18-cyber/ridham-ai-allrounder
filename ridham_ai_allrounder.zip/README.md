# RIDHAM AI ALLROUNDER — Free Edition (Vercel + Gemini)

This is a minimal Next.js demo app for **RIDHAM AI ALLROUNDER**. It uses the Google Generative Language (Gemini) API for chat so you can run it without OpenAI billing.

## Setup (Local / Vercel)

### 1. Get a Gemini API Key
- Visit: https://makersuite.google.com/app/apikey
- Create an API key and copy it.

### 2. Deploy to Vercel (recommended)
- Push this repo to GitHub.
- Sign in to https://vercel.com and import the repository.
- In Vercel project settings → Environment Variables, add:
  - `GEMINI_API_KEY` = your_api_key_here
- Deploy.

### 3. Run locally (optional)
- Install dependencies: `npm install`
- Set `GEMINI_API_KEY` in your environment (Linux/macOS): `export GEMINI_API_KEY=your_key`
- Run dev: `npm run dev`

## Notes
- This project is intentionally minimal. For image-generation, image-editing, and PDF parsing, you will need to extend API routes and integrate appropriate Google or other provider endpoints.
- Keep your API keys secret.

-- RIDHAM
